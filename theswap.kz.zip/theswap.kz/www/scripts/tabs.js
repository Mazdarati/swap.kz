function tab1(){
    $.ajax({
    	url: "sidebar/tabs/tab1.php",
    	cache: true,
    	success: function(html){
    	   $("#sidebar").html(html);
    	} 
    });
}
function tab2(){
    $.ajax({
		url: "sidebar/tabs/tab2.php",
		cache: true,
		success: function(html){
			$("#sidebar").html(html);
		} 
	});
}
function tab3(){
    $.ajax({
		url: "sidebar/tabs/tab3.php",
		cache: true,
		success: function(html){
			$("#sidebar").html(html);
		} 
	});
 }
function tab4(){
    $.ajax({
		url: "sidebar/tabs/tab4.php",
		cache: true,
		success: function(html){
	       $("#sidebar").html(html);
        }   
    });
}
$(document).ready(function(){
    tab1();
});