$(document).ready(function(){
    // If you click Login button.
    $('.swp_login').click(function(){
        $('#forguest').fadeOut(0,function(){$(this).removeAttr('id').html(' ').fadeIn().addClass('loader');});
        $.ajax({
          url: 'swp_login.php',
          success: function(data) {
            $('.loader').removeClass('loader').addClass('login').html(data);
          }
        });
    });
    $('#sw_con_form_log').submit(function(){
        $.ajax({
          url: 'swp_login.php',
          success: function(data) {
            $('.loader').removeClass('loader').addClass('login').html(data);
          }
        });
        return false;
    });
    // If you click Logout button
    $('.swp_logout').click(function(){
        $('.login').fadeOut(0,function(){$(this).removeClass('login').html(' ').fadeIn().addClass('loader');});
        $.ajax({
          url: 'swp_act_exit.php',
          success: function(data) {
            $('.loader').removeClass('loader').attr('id','forguest').html(data);
          }
        });
    });
    //If you click Registration button
    $('.swp_registration').click(function(){
       $('#content').fadeOut(0,function(){$(this).removeAttr('id').html(' ').fadeIn().addClass('loader2');});
        $.ajax({
          url: 'swp_signup.php',
          success: function(data) {
            $('.loader2').removeClass('loader2').attr('id','content2').html(data);
          }
        });
    });
    
});

