<div id="sidebarMenu">
	<a id="tab1" href="javascript:tab1()"><img src="img/main.png" /></a><br />
	<a id="tab2" href="javascript:tab2()"><img src="img/profile1.png" /></a><br />
	<a id="tab3" href="javascript:tab3()"><img src="img/categories.png" /></a><br />
</div>
<div id="categories">
	<p><a href="">Все категории</a></p>
	<p><a href="">Книги, фильмы, музыка</a></p>
	<p><a href="">Электронная техника</a></p>
	<p><a href="">Спортивные товары</a></p>
	<p><a href="">Модная одежда</a></p>
	<p><a href="">Автомобили</a></p>
</div>
