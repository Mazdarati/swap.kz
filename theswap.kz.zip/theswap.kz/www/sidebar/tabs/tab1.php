<div id="forguest" style="color:#006600;text-shadow:0px 1px 0px #33FF33,0px 0px 10px #33FF33;">
	<center><b>добро пожаловать на <p>THE SWAP</p></b></center>
</div>
<div id="forguest" style="color:#006600;font-size:18px;padding-top:3px;padding-bottom:3px;;text-shadow:0px 1px 0px #33FF33,0px 0px 10px #33FF33;">
	<center>THESWAP Beta v0.2</center>
</div>
<div id="sidebarMenu">
	<a id="tab1" href="javascript:tab1()"><img src="img/main.png" /></a><br />
	<a id="tab2" href="javascript:tab2()"><img src="img/profile1.png" /></a><br />
	<a id="tab3" href="javascript:tab3()"><img src="img/categories.png" /></a><br />
</div>
