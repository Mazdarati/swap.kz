<div id="forguest">
	<p>Логин: <input type="text" size="17" style="width:65%;margin-left:8px;"/></p>
	<p>Пароль: <input type="text" size="16" style="width:65%;"/></p>
	<center><button valign="center" style="font-family:'Tahoma',Times,serif;">Войти</button></center>
	<hr noshade color="#d7d7d7" size="1" width="255">
	<a href="">Помощь</a>
</div>
<div id="sidebarMenu">
	<a href=""><img src="img/main.png"/></a><br>
	<a href="mainp.html"><img src="img/profile1.png"/></a></br>
	<a href="mainc.html"><img src="img/categories.png"/></a></br>
</div>
<div id="categories">
	<p><a href="">Все категории</a></p>
	<p><a href="">Книги, фильмы, музыка</a></p>
	<p><a href="">Электронная техника</a></p>
	<p><a href="">Спортивные товары</a></p>
	<p><a href="">Модная одежда</a></p>
	<p><a href="">Автомобили</a></p>
</div>
