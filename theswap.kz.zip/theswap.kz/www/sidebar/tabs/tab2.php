<div id="sidebarBlock">
	<div id="sidebarBlockPhoto"><img src="img/hb.jpg"/></div>
	Честер Беннингтон<br/><br/>
	Рейтинг: --------------<br/>
	<hr noshade color="#FFFFFF" size="1" width="145" align="right">
	<a href="ownpage.html">Личная страница</a><br/>
	<a href="">Отзывы(7)</a><br/>
	<a href="">Offer you(12)</a><br/>
	<a href="">Edit the data</a><br/>
	<hr noshade color="#FFFFFF" size="1" width="145" align="right"><br/>
	Own contact data:<br/>
	<img src="img/tw.png"></img> twitter.com/chbennington<br/>
	gm chesterbennington@gmail.com</br>
	sc ch_bennington<br/>
	<img src="img/fb.gif"> facebook.com/chbennington<br/>
</div>
<div id="sidebarBlock2">
	<div id="categories2">
		<p><a href="">Trash(43)</a></p>
		<p><a href="">Last looked goods(5)</a></p>
	</div>
</div>
<div id="sidebarMenu">
	<a id="tab1" href="javascript:tab1()"><img src="img/main.png" /></a><br />
	<a id="tab2" href="javascript:tab2()"><img src="img/profile1.png" /></a><br />
	<a id="tab3" href="javascript:tab3()"><img src="img/categories.png" /></a><br />
</div>

